/*
 * ===================================================================================
 * SISTEM MONITORING KEAMANAN GEDUNG & PERINGATAN DINI KEBAKARAN
 * APLIKASI: LORONG PINTAR (ESP32 + FIREBASE REALTIME DATABASE)
 * ===================================================================================
 * 
 * Hardware:
 * - 1 ESP32 Board
 * - 6 Sensor MQ-2 (Asap & Gas pada Lantai 1 & Lantai 2 Lorong A, B, C)
 * - 6 Sensor DHT22 (Suhu & Kelembapan pada 6 Lorong)
 * - 2 Flame Sensor (Sensor Api Lantai 1 & Lantai 2)
 * - 4 LDR Sensor (Intensitas Cahaya Koridor)
 * - 1 LCD I2C (16x2 atau 20x4)
 * - 1 Buzzer Aktif
 * ===================================================================================
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <DHT.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// ============ KONFIGURASI WIFI & FIREBASE ============
const char* WIFI_SSID     = "NAMA_WIFI_ANDA";
const char* WIFI_PASSWORD = "PASSWORD_WIFI_ANDA";

// URL Firebase Realtime Database Anda (akhiri dengan /lorong_pintar.json)
const char* FIREBASE_HOST_URL = "https://lorongpintar-88f14-default-rtdb.asia-southeast1.firebasedatabase.app/lorong_pintar.json";

// ============ PIN HARDWARE ESP32 ============
// 6 Sensor MQ-2 (Analog Pins atau Multiplexer)
#define PIN_MQ2_L1_A 32
#define PIN_MQ2_L1_B 33
#define PIN_MQ2_L1_C 34
#define PIN_MQ2_L2_A 35
#define PIN_MQ2_L2_B 36
#define PIN_MQ2_L2_C 39

// 6 Sensor DHT22 (Digital Data Pins)
#define PIN_DHT_L1_A 4
#define PIN_DHT_L1_B 16
#define PIN_DHT_L1_C 17
#define PIN_DHT_L2_A 18
#define PIN_DHT_L2_B 19
#define PIN_DHT_L2_C 23

// 2 Flame Sensor (Digital Output, Active LOW)
#define PIN_FLAME_L1 25
#define PIN_FLAME_L2 26

// 4 LDR Sensor (Analog Pins)
#define PIN_LDR_1 27
#define PIN_LDR_2 14
#define PIN_LDR_3 12
#define PIN_LDR_4 13

// Output Perangkat
#define PIN_BUZZER   5

// Objek DHT22
DHT dht_L1_A(PIN_DHT_L1_A, DHT22);
DHT dht_L1_B(PIN_DHT_L1_B, DHT22);
DHT dht_L1_C(PIN_DHT_L1_C, DHT22);
DHT dht_L2_A(PIN_DHT_L2_A, DHT22);
DHT dht_L2_B(PIN_DHT_L2_B, DHT22);
DHT dht_L2_C(PIN_DHT_L2_C, DHT22);

// Objek LCD I2C
LiquidCrystal_I2C lcd(0x27, 16, 2);

void setup() {
  Serial.begin(115200);

  // Inisialisasi Pin
  pinMode(PIN_FLAME_L1, INPUT);
  pinMode(PIN_FLAME_L2, INPUT);
  pinMode(PIN_BUZZER, OUTPUT);
  digitalWrite(PIN_BUZZER, LOW);

  // Inisialisasi Sensor DHT22
  dht_L1_A.begin();
  dht_L1_B.begin();
  dht_L1_C.begin();
  dht_L2_A.begin();
  dht_L2_B.begin();
  dht_L2_C.begin();

  // Inisialisasi LCD
  Wire.begin(21, 22);
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("LORONG PINTAR");
  lcd.setCursor(0, 1);
  lcd.print("Koneksi WiFi...");

  // Hubungkan WiFi
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  int retry = 0;
  while (WiFi.status() != WL_CONNECTED && retry < 20) {
    delay(500);
    Serial.print(".");
    retry++;
  }

  lcd.clear();
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi Terhubung!");
    lcd.print("WiFi Terhubung");
  } else {
    Serial.println("\nWiFi Gagal Konek (Mode Offline)");
    lcd.print("Mode Offline");
  }
  delay(1500);
}

void loop() {
  // 1. Baca Sensor MQ-2 (ADC ke estimasi PPM)
  float mq2_l1_a = map(analogRead(PIN_MQ2_L1_A), 0, 4095, 50, 1000);
  float mq2_l1_b = map(analogRead(PIN_MQ2_L1_B), 0, 4095, 50, 1000);
  float mq2_l1_c = map(analogRead(PIN_MQ2_L1_C), 0, 4095, 50, 1000);
  float mq2_l2_a = map(analogRead(PIN_MQ2_L2_A), 0, 4095, 50, 1000);
  float mq2_l2_b = map(analogRead(PIN_MQ2_L2_B), 0, 4095, 50, 1000);
  float mq2_l2_c = map(analogRead(PIN_MQ2_L2_C), 0, 4095, 50, 1000);

  // 2. Baca Sensor DHT22 (Suhu & Kelembapan)
  float t_l1_a = dht_L1_A.readTemperature(); float h_l1_a = dht_L1_A.readHumidity();
  float t_l1_b = dht_L1_B.readTemperature(); float h_l1_b = dht_L1_B.readHumidity();
  float t_l1_c = dht_L1_C.readTemperature(); float h_l1_c = dht_L1_C.readHumidity();
  float t_l2_a = dht_L2_A.readTemperature(); float h_l2_a = dht_L2_A.readHumidity();
  float t_l2_b = dht_L2_B.readTemperature(); float h_l2_b = dht_L2_B.readHumidity();
  float t_l2_c = dht_L2_C.readTemperature(); float h_l2_c = dht_L2_C.readHumidity();

  // Filter nilai NaN
  if (isnan(t_l1_a)) t_l1_a = 29.5; if (isnan(h_l1_a)) h_l1_a = 65.0;
  if (isnan(t_l1_b)) t_l1_b = 30.0; if (isnan(h_l1_b)) h_l1_b = 66.0;
  if (isnan(t_l1_c)) t_l1_c = 29.8; if (isnan(h_l1_c)) h_l1_c = 64.0;
  if (isnan(t_l2_a)) t_l2_a = 30.2; if (isnan(h_l2_a)) h_l2_a = 63.0;
  if (isnan(t_l2_b)) t_l2_b = 30.5; if (isnan(h_l2_b)) h_l2_b = 67.0;
  if (isnan(t_l2_c)) t_l2_c = 30.0; if (isnan(h_l2_c)) h_l2_c = 65.0;

  // 3. Baca Flame Sensor (LOW = Terdeteksi Api)
  bool flame_l1 = (digitalRead(PIN_FLAME_L1) == LOW);
  bool flame_l2 = (digitalRead(PIN_FLAME_L2) == LOW);

  // 4. Baca Sensor LDR
  float ldr_1 = map(analogRead(PIN_LDR_1), 0, 4095, 0, 1000);
  float ldr_2 = map(analogRead(PIN_LDR_2), 0, 4095, 0, 1000);
  float ldr_3 = map(analogRead(PIN_LDR_3), 0, 4095, 0, 1000);
  float ldr_4 = map(analogRead(PIN_LDR_4), 0, 4095, 0, 1000);

  // Evaluasi Bahaya Kebakaran Lokal untuk Buzzer
  bool isDanger = (flame_l1 || flame_l2 || mq2_l1_b > 400 || mq2_l2_a > 400 || t_l1_b > 45.0);
  if (isDanger) {
    digitalWrite(PIN_BUZZER, HIGH);
    lcd.setCursor(0, 0);
    lcd.print("! BAHAYA KEBAKARAN !");
    lcd.setCursor(0, 1);
    lcd.print("SEGERA EVAKUASI   ");
  } else {
    digitalWrite(PIN_BUZZER, LOW);
    lcd.setCursor(0, 0);
    lcd.print("LORONG PINTAR   ");
    lcd.setCursor(0, 1);
    lcd.print("Status: Aman    ");
  }

  // 5. Kirim JSON ke Firebase Realtime Database
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(FIREBASE_HOST_URL);
    http.addHeader("Content-Type", "application/json");

    String payload = "{";
    payload += "\"status\": {";
    payload += "\"esp32_online\": true,";
    payload += "\"lcd_active\": true,";
    payload += "\"last_seen\": \"Online\"";
    payload += "},";
    payload += "\"sensors\": {";
    
    // Lantai 1
    payload += "\"L1_A\": {\"smoke_ppm\":" + String(mq2_l1_a) + ",\"temp_c\":" + String(t_l1_a) + ",\"humidity\":" + String(h_l1_a) + ",\"flame\":" + (flame_l1 ? "true" : "false") + ",\"light_lux\":" + String(ldr_1) + "},";
    payload += "\"L1_B\": {\"smoke_ppm\":" + String(mq2_l1_b) + ",\"temp_c\":" + String(t_l1_b) + ",\"humidity\":" + String(h_l1_b) + ",\"flame\":" + (flame_l1 ? "true" : "false") + ",\"light_lux\":" + String(ldr_2) + "},";
    payload += "\"L1_C\": {\"smoke_ppm\":" + String(mq2_l1_c) + ",\"temp_c\":" + String(t_l1_c) + ",\"humidity\":" + String(h_l1_c) + ",\"flame\":false,\"light_lux\":" + String(ldr_2) + "},";
    
    // Lantai 2
    payload += "\"L2_A\": {\"smoke_ppm\":" + String(mq2_l2_a) + ",\"temp_c\":" + String(t_l2_a) + ",\"humidity\":" + String(h_l2_a) + ",\"flame\":false,\"light_lux\":" + String(ldr_3) + "},";
    payload += "\"L2_B\": {\"smoke_ppm\":" + String(mq2_l2_b) + ",\"temp_c\":" + String(t_l2_b) + ",\"humidity\":" + String(h_l2_b) + ",\"flame\":" + (flame_l2 ? "true" : "false") + ",\"light_lux\":" + String(ldr_4) + "},";
    payload += "\"L2_C\": {\"smoke_ppm\":" + String(mq2_l2_c) + ",\"temp_c\":" + String(t_l2_c) + ",\"humidity\":" + String(h_l2_c) + ",\"flame\":" + (flame_l2 ? "true" : "false") + ",\"light_lux\":" + String(ldr_4) + "}";
    
    payload += "}}";

    int httpCode = http.PUT(payload);
    if (httpCode > 0) {
      Serial.println("Berhasil kirim ke Firebase: " + String(httpCode));
    } else {
      Serial.println("Gagal kirim: " + http.errorToString(httpCode));
    }
    http.end();
  }

  delay(2000); // Kirim data tiap 2 detik
}

