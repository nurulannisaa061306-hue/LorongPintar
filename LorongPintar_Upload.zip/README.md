# 🏢 LorongPintar - Smart Building Fire Safety & Evacuation System

Sistem Monitoring Keselamatan Gedung & Peringatan Dini Kebakaran Bertingkat Berbasis **IoT (ESP32)**, **Cloud (Firebase Realtime Database)**, dan **Aplikasi Mobile (Android Kotlin)**.

Repository Resmi: [https://github.com/nurulannisaa061306-hue](https://github.com/nurulannisaa061306-hue)

---

## 🌟 Fitur Utama

1. **Denah Miniatur 2 Lantai Bergradasi Realtime**: Visualisasi kondisi koridor Lantai 1 & Lantai 2 dengan gradasi warna dinamis (Aman: Hijau, Siaga: Oranye/Kuning, Bahaya: Merah Api).
2. **Algoritma Rekomendasi Evakuasi Cerdas (*Smart Evacuation Routing*)**: Otomatis menganalisis koridor yang terbakar dan mengalihkan jalur penyelamatan ke tangga evakuasi yang bebas hambatan (Tangga A / Tangga B).
3. **Peringatan Notifikasi & Suara Darurat Kustom**: Notifikasi *heads-up* darurat dengan nada peringatan (*Hazard Alert Tone*) dan getaran fisik HP saat terdeteksi api/asap.
4. **Sinkronisasi Cloud Realtime**: Terhubung langsung dengan Firebase Realtime Database setiap 2,5 detik.
5. **Mode Dual (Simulasi & Perangkat Asli)**:
   - **Mode Simulasi**: Memungkinkan demonstrasi 4 skenario darurat langsung di aplikasi tanpa memerlukan alat fisik.
   - **Mode Perangkat Asli**: Membaca data langsung dari sensor fisik ESP32 via Firebase.

---

## 🏗️ Arsitektur Sistem

```
[ Sensor Fisik (MQ-2, DHT22, Flame, LDR) ]
                    │
                    ▼
           [ Board ESP32 ] 
                    │ (Kirim Data JSON via WiFi / HTTP PUT)
                    ▼
     [ Firebase Realtime Database ]
                    │ (Polling Realtime tiap 2.5 Detik / HTTP GET)
                    ▼
    [ Aplikasi Android (LorongPintar) ]
```

---

## 📡 Konfigurasi Firebase Realtime Database

- **Database URL**: `https://lorongpintar-88f14-default-rtdb.asia-southeast1.firebasedatabase.app/`
- **Path Node**: `/lorong_pintar.json`
- **Aturan Akses (*Security Rules*)**:
  ```json
  {
    "rules": {
      ".read": true,
      ".write": true
    }
  }
  ```
- **Struktur JSON Awal**: Tersedia di file [`lorong_pintar_data.json`](lorong_pintar_data.json).

---

## 🔌 Hardware & Program ESP32

File program ESP32 terletak di: [`esp32/lorong_pintar_esp32.ino`](esp32/lorong_pintar_esp32.ino).

### Pin Out Sensor ESP32:
- **MQ-2 (Sensor Asap & Gas)**: Pin Analog `32, 33, 34, 35, 36, 39`
- **DHT22 (Sensor Suhu & Kelembapan)**: Pin Digital `4, 16, 17, 18, 19, 23`
- **Flame Sensor (Sensor Api)**: Pin Digital `25, 26` (Active LOW)
- **Buzzer Alarm**: Pin `5`
- **LCD I2C 16x2**: SDA `21`, SCL `22`

---

## 🚀 Panduan Menjalankan Aplikasi di Android Studio

1. **Clone Repository ini**:
   ```bash
   git clone https://github.com/nurulannisaa061306-hue/LorongPintar.git
   ```
2. Buka folder proyek di **Android Studio**.
3. Tunggu proses **Gradle Sync** selesai.
4. Hubungkan HP Android atau nyalakan Emulator.
5. Klik menu **Build** ➔ **Rebuild Project**, lalu klik tombol hijau **Run (▶️)**.
6. Aplikasi langsung terhubung ke database Firebase secara *out-of-the-box*!
