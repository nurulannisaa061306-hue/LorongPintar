package com.example.lorongpintar

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.lorongpintar.data.BuildingDataManager
import com.example.lorongpintar.model.StatusLevel
import com.example.lorongpintar.ui.view.MonitoringChartView
import com.example.lorongpintar.util.NotificationHelper
import com.google.android.material.button.MaterialButton
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    // Header Views
    private lateinit var tvEsp32Text: TextView
    private lateinit var dotEsp32: View
    private lateinit var ivWifi: ImageView
    private lateinit var tvHeaderTime: TextView
    private lateinit var tvHeaderDate: TextView
    private lateinit var tvModeLabel: TextView

    // Status Summary Cards
    private lateinit var tvCountAman: TextView
    private lateinit var tvCountSiaga: TextView
    private lateinit var tvCountBahaya: TextView

    // Denah Miniatur Lorong
    private lateinit var btnL2A: LinearLayout
    private lateinit var btnL2B: LinearLayout
    private lateinit var btnL2C: LinearLayout
    private lateinit var btnL1A: LinearLayout
    private lateinit var btnL1B: LinearLayout
    private lateinit var btnL1C: LinearLayout

    private lateinit var ivIconL2A: ImageView
    private lateinit var ivIconL2B: ImageView
    private lateinit var ivIconL2C: ImageView
    private lateinit var ivIconL1A: ImageView
    private lateinit var ivIconL1B: ImageView
    private lateinit var ivIconL1C: ImageView

    // 5 Sensor Cards
    private lateinit var tvSmokeVal: TextView
    private lateinit var badgeSmoke: TextView
    private lateinit var tvTempVal: TextView
    private lateinit var badgeTemp: TextView
    private lateinit var tvHumVal: TextView
    private lateinit var badgeHum: TextView
    private lateinit var tvFlameVal: TextView
    private lateinit var badgeFlame: TextView
    private lateinit var tvLightVal: TextView
    private lateinit var badgeLight: TextView

    // Peringatan Terbaru & Evakuasi
    private lateinit var cardPeringatan: LinearLayout
    private lateinit var ivAlertIcon: ImageView
    private lateinit var tvAlertTitle: TextView
    private lateinit var tvAlertLocation: TextView
    private lateinit var tvAlertTime: TextView
    private lateinit var badgeAlertStatus: TextView
    private lateinit var tvEvacStairName: TextView
    private lateinit var tvEvacInstruction: TextView

    // Grafik Monitoring
    private lateinit var chartView: MonitoringChartView
    private lateinit var btnChartSuhu: TextView
    private lateinit var btnChartKelembapan: TextView
    private lateinit var tvChartYTop: TextView
    private lateinit var tvChartYMid: TextView
    private lateinit var tvChartYBot: TextView
    private var isChartTempActive = true

    // Status Perangkat IoT
    private lateinit var dotEsp32Dev: View
    private lateinit var tvEsp32DevStatus: TextView
    private lateinit var dotLcdDev: View
    private lateinit var tvLcdDevStatus: TextView
    private lateinit var dotBuzzerDev: View
    private lateinit var tvBuzzerDevStatus: TextView

    // Bottom Action Bar
    private lateinit var ivSystemShield: ImageView
    private lateinit var tvSystemOverallText: TextView
    private lateinit var badgeSystemOverall: LinearLayout

    private val timeHandler = Handler(Looper.getMainLooper())
    private lateinit var timeRunnable: Runnable
    private var lastDangerCount = 0
    private var lastWarningCount = 0
    private var lastAlertLocation: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main_scroll_view)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        NotificationHelper.createNotificationChannel(this)
        requestNotificationPermissionIfNeeded()

        BuildingDataManager.init(this)
        bindViews()
        setupListeners()
        startLiveClock()

        BuildingDataManager.registerListener {
            updateDashboardUI()
        }

        updateDashboardUI()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }
    }

    private fun bindViews() {
        tvEsp32Text = findViewById(R.id.tv_esp32_connection_text)
        dotEsp32 = findViewById(R.id.dot_esp32_connection)
        ivWifi = findViewById(R.id.iv_wifi_status)
        tvHeaderTime = findViewById(R.id.tv_header_time)
        tvHeaderDate = findViewById(R.id.tv_header_date)
        tvModeLabel = findViewById(R.id.tv_mode_label)

        tvCountAman = findViewById(R.id.tv_count_aman)
        tvCountSiaga = findViewById(R.id.tv_count_siaga)
        tvCountBahaya = findViewById(R.id.tv_count_bahaya)

        btnL2A = findViewById(R.id.btn_koridor_l2_a)
        btnL2B = findViewById(R.id.btn_koridor_l2_b)
        btnL2C = findViewById(R.id.btn_koridor_l2_c)
        btnL1A = findViewById(R.id.btn_koridor_l1_a)
        btnL1B = findViewById(R.id.btn_koridor_l1_b)
        btnL1C = findViewById(R.id.btn_koridor_l1_c)

        ivIconL2A = findViewById(R.id.iv_icon_l2_a)
        ivIconL2B = findViewById(R.id.iv_icon_l2_b)
        ivIconL2C = findViewById(R.id.iv_icon_l2_c)
        ivIconL1A = findViewById(R.id.iv_icon_l1_a)
        ivIconL1B = findViewById(R.id.iv_icon_l1_b)
        ivIconL1C = findViewById(R.id.iv_icon_l1_c)

        tvSmokeVal = findViewById(R.id.tv_sensor_asap_val)
        badgeSmoke = findViewById(R.id.badge_sensor_asap)
        tvTempVal = findViewById(R.id.tv_sensor_suhu_val)
        badgeTemp = findViewById(R.id.badge_sensor_suhu)
        tvHumVal = findViewById(R.id.tv_sensor_kelembapan_val)
        badgeHum = findViewById(R.id.badge_sensor_kelembapan)
        tvFlameVal = findViewById(R.id.tv_sensor_api_val)
        badgeFlame = findViewById(R.id.badge_sensor_api)
        tvLightVal = findViewById(R.id.tv_sensor_ldr_val)
        badgeLight = findViewById(R.id.badge_sensor_ldr)

        cardPeringatan = findViewById(R.id.card_peringatan_terbaru)
        ivAlertIcon = findViewById(R.id.iv_alert_icon_main)
        tvAlertTitle = findViewById(R.id.tv_alert_title_main)
        tvAlertLocation = findViewById(R.id.tv_alert_location_main)
        tvAlertTime = findViewById(R.id.tv_alert_time_main)
        badgeAlertStatus = findViewById(R.id.badge_alert_status_main)

        tvEvacStairName = findViewById(R.id.tv_evac_stair_name)
        tvEvacInstruction = findViewById(R.id.tv_evac_instruction)

        chartView = findViewById(R.id.chart_view_monitoring)
        btnChartSuhu = findViewById(R.id.btn_chart_tab_suhu)
        btnChartKelembapan = findViewById(R.id.btn_chart_tab_kelembapan)
        tvChartYTop = findViewById(R.id.tv_chart_y_top)
        tvChartYMid = findViewById(R.id.tv_chart_y_mid)
        tvChartYBot = findViewById(R.id.tv_chart_y_bot)

        dotEsp32Dev = findViewById(R.id.dot_device_esp32)
        tvEsp32DevStatus = findViewById(R.id.tv_device_esp32_status)
        dotLcdDev = findViewById(R.id.dot_device_lcd)
        tvLcdDevStatus = findViewById(R.id.tv_device_lcd_status)
        dotBuzzerDev = findViewById(R.id.dot_device_buzzer)
        tvBuzzerDevStatus = findViewById(R.id.tv_device_buzzer_status)

        ivSystemShield = findViewById(R.id.iv_system_shield)
        tvSystemOverallText = findViewById(R.id.tv_system_overall_text)
        badgeSystemOverall = findViewById(R.id.badge_system_overall)
    }

    private fun setupListeners() {
        findViewById<View>(R.id.btn_open_settings).setOnClickListener { showSettingsDialog() }
        findViewById<View>(R.id.btn_theme_or_mode).setOnClickListener { showSettingsDialog() }
        findViewById<View>(R.id.btn_status_esp32_header).setOnClickListener { showSettingsDialog() }
        findViewById<View>(R.id.btn_switch_mode_action).setOnClickListener { showSettingsDialog() }
        findViewById<View>(R.id.btn_scenario_hub)?.setOnClickListener { showDemoScenariosDialog() }
        findViewById<View>(R.id.tv_mode_label)?.setOnClickListener { showDemoScenariosDialog() }

        // Klik masing-masing lorong pada denah miniatur
        btnL2A.setOnClickListener { showLorongDetailDialog("L2_A") }
        btnL2B.setOnClickListener { showLorongDetailDialog("L2_B") }
        btnL2C.setOnClickListener { showLorongDetailDialog("L2_C") }
        btnL1A.setOnClickListener { showLorongDetailDialog("L1_A") }
        btnL1B.setOnClickListener { showLorongDetailDialog("L1_B") }
        btnL1C.setOnClickListener { showLorongDetailDialog("L1_C") }

        // Klik card sensor -> Dialog rincian seluruh 18 sensor
        findViewById<View>(R.id.btn_lihat_semua_sensor).setOnClickListener { showAllSensorsDialog() }
        findViewById<View>(R.id.card_sensor_asap).setOnClickListener { showAllSensorsDialog() }
        findViewById<View>(R.id.card_sensor_suhu).setOnClickListener { showAllSensorsDialog() }
        findViewById<View>(R.id.card_sensor_kelembapan).setOnClickListener { showAllSensorsDialog() }
        findViewById<View>(R.id.card_sensor_api).setOnClickListener { showAllSensorsDialog() }
        findViewById<View>(R.id.card_sensor_ldr).setOnClickListener { showAllSensorsDialog() }

        // Peringatan & Evakuasi -> Dialog SOP Evakuasi & Konfirmasi
        cardPeringatan.setOnClickListener { showSopEvacDialog() }
        findViewById<View>(R.id.card_rekomendasi_evakuasi).setOnClickListener { showSopEvacDialog() }

        // Riwayat
        findViewById<View>(R.id.btn_open_riwayat_bottom).setOnClickListener { showRiwayatDialog() }

        // Chart Switcher Suhu vs Kelembapan
        btnChartSuhu.setOnClickListener {
            isChartTempActive = true
            btnChartSuhu.setBackgroundResource(R.drawable.bg_chip_chart_active)
            btnChartSuhu.setTextColor(Color.WHITE)
            btnChartKelembapan.background = null
            btnChartKelembapan.setTextColor(Color.parseColor("#94A3B8"))
            updateChartData()
        }

        btnChartKelembapan.setOnClickListener {
            isChartTempActive = false
            btnChartKelembapan.setBackgroundResource(R.drawable.bg_chip_chart_active)
            btnChartKelembapan.setTextColor(Color.WHITE)
            btnChartSuhu.background = null
            btnChartSuhu.setTextColor(Color.parseColor("#94A3B8"))
            updateChartData()
        }
    }

    private fun startLiveClock() {
        timeRunnable = object : Runnable {
            override fun run() {
                val now = Date()
                tvHeaderTime.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
                tvHeaderDate.text = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(now)
                timeHandler.postDelayed(this, 1000)
            }
        }
        timeHandler.post(timeRunnable)
    }

    private fun updateDashboardUI() {
        // Mode Banner
        if (BuildingDataManager.isRealDeviceMode) {
            tvModeLabel.text = "● MODE PERANGKAT ASLI (Sinkronisasi Firebase Realtime Database)"
            tvModeLabel.setTextColor(Color.parseColor("#059669"))
        } else {
            tvModeLabel.text = "● MODE SIMULASI (Klik lorong untuk uji bahaya & evakuasi)"
            tvModeLabel.setTextColor(Color.parseColor("#2563EB"))
        }

        // ESP32 Status Header
        val isOnline = BuildingDataManager.hardwareStatus.esp32Connected
        tvEsp32Text.text = if (isOnline) "Terhubung" else "Offline"
        tvEsp32Text.setTextColor(if (isOnline) Color.parseColor("#059669") else Color.parseColor("#DC2626"))
        dotEsp32.setBackgroundResource(if (isOnline) R.drawable.dot_green else R.drawable.dot_red)

        // Count Lorong
        tvCountAman.text = BuildingDataManager.getAmanCount().toString()
        tvCountSiaga.text = BuildingDataManager.getSiagaCount().toString()
        tvCountBahaya.text = BuildingDataManager.getBahayaCount().toString()

        // Update Denah Lorong
        updateCorridorView("L2_A", btnL2A, ivIconL2A)
        updateCorridorView("L2_B", btnL2B, ivIconL2B)
        updateCorridorView("L2_C", btnL2C, ivIconL2C)
        updateCorridorView("L1_A", btnL1A, ivIconL1A)
        updateCorridorView("L1_B", btnL1B, ivIconL1B)
        updateCorridorView("L1_C", btnL1C, ivIconL1C)

        // 5 Card Sensor
        val maxSmoke = BuildingDataManager.getMaxSmoke()
        tvSmokeVal.text = "${maxSmoke.toInt()} ppm"
        if (maxSmoke >= BuildingDataManager.smokeBahaya) {
            badgeSmoke.text = "Bahaya"
            badgeSmoke.setBackgroundResource(R.drawable.bg_badge_danger)
            badgeSmoke.setTextColor(Color.parseColor("#DC2626"))
        } else if (maxSmoke >= BuildingDataManager.smokeSiaga) {
            badgeSmoke.text = "Siaga"
            badgeSmoke.setBackgroundResource(R.drawable.bg_badge_warning)
            badgeSmoke.setTextColor(Color.parseColor("#D97706"))
        } else {
            badgeSmoke.text = "Normal"
            badgeSmoke.setBackgroundResource(R.drawable.bg_badge_normal)
            badgeSmoke.setTextColor(Color.parseColor("#059669"))
        }

        val maxTemp = BuildingDataManager.getMaxTemp()
        tvTempVal.text = String.format(Locale.US, "%.1f °C", maxTemp)
        if (maxTemp >= BuildingDataManager.tempBahaya) {
            badgeTemp.text = "Bahaya"
            badgeTemp.setBackgroundResource(R.drawable.bg_badge_danger)
            badgeTemp.setTextColor(Color.parseColor("#DC2626"))
        } else if (maxTemp >= BuildingDataManager.tempSiaga) {
            badgeTemp.text = "Siaga"
            badgeTemp.setBackgroundResource(R.drawable.bg_badge_warning)
            badgeTemp.setTextColor(Color.parseColor("#D97706"))
        } else {
            badgeTemp.text = "Normal"
            badgeTemp.setBackgroundResource(R.drawable.bg_badge_normal)
            badgeTemp.setTextColor(Color.parseColor("#059669"))
        }

        val avgHum = BuildingDataManager.getAvgHumidity()
        tvHumVal.text = "${avgHum.toInt()} %"
        badgeHum.text = "Normal"
        badgeHum.setBackgroundResource(R.drawable.bg_badge_normal)
        badgeHum.setTextColor(Color.parseColor("#059669"))

        val isFlame = BuildingDataManager.isAnyFlameDetected()
        if (isFlame) {
            tvFlameVal.text = "Terdeteksi"
            badgeFlame.text = "Bahaya"
            badgeFlame.setBackgroundResource(R.drawable.bg_badge_danger)
            badgeFlame.setTextColor(Color.parseColor("#DC2626"))
        } else {
            tvFlameVal.text = "Tidak Terdeteksi"
            badgeFlame.text = "Normal"
            badgeFlame.setBackgroundResource(R.drawable.bg_badge_normal)
            badgeFlame.setTextColor(Color.parseColor("#059669"))
        }

        val avgLight = BuildingDataManager.getAvgLight()
        tvLightVal.text = "${avgLight.toInt()} lux"
        badgeLight.text = "Normal"
        badgeLight.setBackgroundResource(R.drawable.bg_badge_normal)
        badgeLight.setTextColor(Color.parseColor("#059669"))

        // Alert Card
        val alert = BuildingDataManager.getLatestAlert()
        if (alert != null) {
            cardPeringatan.setBackgroundResource(R.drawable.bg_card_danger_glow)
            ivAlertIcon.setImageResource(R.drawable.ic_flame)
            ivAlertIcon.setColorFilter(Color.parseColor("#DC2626"))
            tvAlertTitle.text = alert.first
            tvAlertTitle.setTextColor(Color.parseColor("#DC2626"))
            tvAlertLocation.text = alert.second
            tvAlertLocation.setTextColor(Color.parseColor("#475569"))
            tvAlertTime.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) + " WIB"
            badgeAlertStatus.text = "Bahaya"
            badgeAlertStatus.setBackgroundResource(R.drawable.bg_badge_danger)
            badgeAlertStatus.setTextColor(Color.parseColor("#DC2626"))
            badgeAlertStatus.visibility = View.VISIBLE
        } else {
            cardPeringatan.setBackgroundResource(R.drawable.bg_card_safe_glow)
            ivAlertIcon.setImageResource(R.drawable.ic_shield_check)
            ivAlertIcon.setColorFilter(Color.parseColor("#059669"))
            tvAlertTitle.text = "Kondisi Gedung Aman"
            tvAlertTitle.setTextColor(Color.parseColor("#059669"))
            tvAlertLocation.text = "Semua 6 koridor dalam batas normal"
            tvAlertLocation.setTextColor(Color.parseColor("#475569"))
            tvAlertTime.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) + " WIB"
            badgeAlertStatus.text = "Normal"
            badgeAlertStatus.setBackgroundResource(R.drawable.bg_badge_normal)
            badgeAlertStatus.setTextColor(Color.parseColor("#059669"))
            badgeAlertStatus.visibility = View.VISIBLE
        }

        // Rekomendasi Evakuasi
        val evac = BuildingDataManager.getEvacuationRecommendation()
        tvEvacStairName.text = evac.recommendedStair
        tvEvacInstruction.text = evac.instruction

        // Push Local Notification saat terjadi BAHAYA atau SIAGA (ESP32 Realtime atau Simulasi)
        val currentDangerCount = BuildingDataManager.getBahayaCount()
        val currentWarningCount = BuildingDataManager.getSiagaCount()

        if (currentDangerCount > 0 && alert != null) {
            if (lastDangerCount == 0 || alert.second != lastAlertLocation) {
                NotificationHelper.showEmergencyAlert(
                    context = this,
                    alertTitle = alert.first,
                    alertLocation = alert.second,
                    recommendedStair = evac.recommendedStair
                )
                lastAlertLocation = alert.second
            }
        } else if (currentDangerCount == 0 && currentWarningCount > 0 && alert != null) {
            if (lastWarningCount == 0 || alert.second != lastAlertLocation) {
                NotificationHelper.showWarningAlert(
                    context = this,
                    alertTitle = alert.first,
                    alertLocation = alert.second
                )
                lastAlertLocation = alert.second
            }
        } else if (currentDangerCount == 0 && currentWarningCount == 0) {
            lastAlertLocation = null
        }
        lastDangerCount = currentDangerCount
        lastWarningCount = currentWarningCount

        updateChartData()

        // Status Hardware
        val dev = BuildingDataManager.hardwareStatus
        tvEsp32DevStatus.text = if (dev.esp32Connected) "Terhubung" else "Offline"
        tvEsp32DevStatus.setTextColor(if (dev.esp32Connected) Color.parseColor("#059669") else Color.parseColor("#DC2626"))
        dotEsp32Dev.setBackgroundResource(if (dev.esp32Connected) R.drawable.dot_green else R.drawable.dot_red)

        tvLcdDevStatus.text = if (dev.lcdActive) "Aktif" else "Offline"
        tvLcdDevStatus.setTextColor(if (dev.lcdActive) Color.parseColor("#059669") else Color.parseColor("#DC2626"))
        dotLcdDev.setBackgroundResource(if (dev.lcdActive) R.drawable.dot_green else R.drawable.dot_red)

        tvBuzzerDevStatus.text = if (dev.buzzerActive) "SIAGA BERBUNYI" else "Siaga"
        tvBuzzerDevStatus.setTextColor(if (dev.buzzerActive) Color.parseColor("#DC2626") else Color.parseColor("#059669"))
        dotBuzzerDev.setBackgroundResource(if (dev.buzzerActive) R.drawable.dot_red else R.drawable.dot_green)

        // Bottom Overall Badge
        val totalBahaya = BuildingDataManager.getBahayaCount()
        val totalSiaga = BuildingDataManager.getSiagaCount()
        if (totalBahaya > 0) {
            tvSystemOverallText.text = "$totalBahaya Bahaya Terdeteksi"
            tvSystemOverallText.setTextColor(Color.parseColor("#DC2626"))
            ivSystemShield.setImageResource(R.drawable.ic_flame)
            ivSystemShield.setColorFilter(Color.parseColor("#DC2626"))
            badgeSystemOverall.setBackgroundResource(R.drawable.bg_badge_danger)
        } else if (totalSiaga > 0) {
            tvSystemOverallText.text = "$totalSiaga Koridor Siaga"
            tvSystemOverallText.setTextColor(Color.parseColor("#D97706"))
            ivSystemShield.setImageResource(R.drawable.ic_warning)
            ivSystemShield.setColorFilter(Color.parseColor("#D97706"))
            badgeSystemOverall.setBackgroundResource(R.drawable.bg_badge_warning)
        } else {
            tvSystemOverallText.text = "Sistem Berjalan Normal"
            tvSystemOverallText.setTextColor(Color.parseColor("#059669"))
            ivSystemShield.setImageResource(R.drawable.ic_shield_check)
            ivSystemShield.setColorFilter(Color.parseColor("#059669"))
            badgeSystemOverall.setBackgroundResource(R.drawable.bg_badge_normal)
        }
    }

    private fun updateCorridorView(corridorId: String, layout: LinearLayout, icon: ImageView) {
        val koridor = BuildingDataManager.koridorList.find { it.id == corridorId } ?: return
        when (koridor.status) {
            StatusLevel.BAHAYA -> {
                layout.setBackgroundResource(R.drawable.bg_corridor_bahaya)
                icon.setImageResource(R.drawable.ic_flame)
                icon.setColorFilter(Color.parseColor("#DC2626"))
            }
            StatusLevel.SIAGA -> {
                layout.setBackgroundResource(R.drawable.bg_corridor_siaga)
                icon.setImageResource(R.drawable.ic_warning)
                icon.setColorFilter(Color.parseColor("#D97706"))
            }
            StatusLevel.AMAN -> {
                layout.setBackgroundResource(R.drawable.bg_corridor_aman)
                icon.setImageResource(R.drawable.ic_check_circle)
                icon.setColorFilter(Color.parseColor("#059669"))
            }
        }
    }

    private fun updateChartData() {
        val series = BuildingDataManager.getChartData(isChartTempActive)
        chartView.setData(series)
        if (isChartTempActive) {
            tvChartYTop.text = "60°"
            tvChartYMid.text = "30°"
            tvChartYBot.text = "0°"
        } else {
            tvChartYTop.text = "100%"
            tvChartYMid.text = "50%"
            tvChartYBot.text = "0%"
        }
    }

    // ================= POPUP DIALOGS =================
    private fun showLorongDetailDialog(corridorId: String) {
        val koridor = BuildingDataManager.koridorList.find { it.id == corridorId } ?: return
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.dialog_lorong_detail)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        dialog.findViewById<TextView>(R.id.tv_dialog_lorong_title).text = "Detail Lantai ${koridor.floor} – ${koridor.name}"
        dialog.findViewById<TextView>(R.id.tv_lorong_smoke_val).text = "${koridor.smokeGasPpm.toInt()} ppm"
        dialog.findViewById<TextView>(R.id.tv_lorong_temp_val).text = String.format(Locale.US, "%.1f °C", koridor.tempCelsius)
        dialog.findViewById<TextView>(R.id.tv_lorong_hum_val).text = "${koridor.humidityPercent.toInt()} %"
        dialog.findViewById<TextView>(R.id.tv_lorong_flame_val).text = if (koridor.flameDetected) "API TERDETEKSI" else "Tidak Terdeteksi"
        dialog.findViewById<TextView>(R.id.tv_lorong_light_val).text = "${koridor.lightLux.toInt()} lux"

        val tvStatus = dialog.findViewById<TextView>(R.id.tv_dialog_lorong_status)
        when (koridor.status) {
            StatusLevel.BAHAYA -> {
                tvStatus.text = "Status: BAHAYA"
                tvStatus.setTextColor(Color.parseColor("#DC2626"))
            }
            StatusLevel.SIAGA -> {
                tvStatus.text = "Status: SIAGA"
                tvStatus.setTextColor(Color.parseColor("#D97706"))
            }
            StatusLevel.AMAN -> {
                tvStatus.text = "Status: AMAN"
                tvStatus.setTextColor(Color.parseColor("#059669"))
            }
        }

        dialog.findViewById<View>(R.id.btn_close_lorong_dialog).setOnClickListener { dialog.dismiss() }

        dialog.findViewById<MaterialButton>(R.id.btn_simulasi_bahaya_api_gas).setOnClickListener {
            lastDangerCount = 0
            lastWarningCount = 0
            lastAlertLocation = null
            BuildingDataManager.setSimulationCorridorState(koridor.id, smoke = 850f, temp = 52f, flame = true, lux = 650f)
            dialog.dismiss()
            Toast.makeText(this, "Simulasi Asap & Api Aktif di ${koridor.name}!", Toast.LENGTH_SHORT).show()
        }

        dialog.findViewById<MaterialButton>(R.id.btn_simulasi_siaga_suhu).setOnClickListener {
            lastDangerCount = 0
            lastWarningCount = 0
            lastAlertLocation = null
            BuildingDataManager.setSimulationCorridorState(koridor.id, smoke = 280f, temp = 38.5f, flame = false, lux = 500f)
            dialog.dismiss()
            Toast.makeText(this, "Simulasi Suhu Meningkat (Siaga) di ${koridor.name}!", Toast.LENGTH_SHORT).show()
        }

        dialog.findViewById<MaterialButton>(R.id.btn_simulasi_kembalikan_normal).setOnClickListener {
            lastDangerCount = 0
            lastWarningCount = 0
            lastAlertLocation = null
            NotificationHelper.stopAlarmSound()
            BuildingDataManager.setSimulationCorridorState(koridor.id, smoke = 120f, temp = 30.5f, flame = false, lux = 480f)
            dialog.dismiss()
            Toast.makeText(this, "${koridor.name} dikembalikan ke kondisi Normal/Aman.", Toast.LENGTH_SHORT).show()
        }

        dialog.show()
    }

    private fun showAllSensorsDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.dialog_detail_all_sensors)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val containerMq2 = dialog.findViewById<LinearLayout>(R.id.container_mq2_list)
        val containerDht = dialog.findViewById<LinearLayout>(R.id.container_dht_list)
        val containerFlame = dialog.findViewById<LinearLayout>(R.id.container_flame_list)
        val containerLdr = dialog.findViewById<LinearLayout>(R.id.container_ldr_list)
        val inflater = LayoutInflater.from(this)

        BuildingDataManager.koridorList.forEach { koridor ->
            // 1. MQ-2 Sensor Asap
            val rowSmoke = inflater.inflate(R.layout.item_sensor_detail_row, containerMq2, false)
            rowSmoke.findViewById<TextView>(R.id.tv_row_sensor_name).text = "Sensor Asap (MQ-2) – ${koridor.name}"
            rowSmoke.findViewById<TextView>(R.id.tv_row_sensor_loc).text = "Lantai ${koridor.floor}"
            rowSmoke.findViewById<TextView>(R.id.tv_row_sensor_val).text = "${koridor.smokeGasPpm.toInt()} ppm"
            val tvStatusSmoke = rowSmoke.findViewById<TextView>(R.id.tv_row_sensor_status)
            if (koridor.smokeGasPpm >= BuildingDataManager.smokeBahaya) {
                tvStatusSmoke.text = "BAHAYA"
                tvStatusSmoke.setTextColor(Color.parseColor("#DC2626"))
            } else if (koridor.smokeGasPpm >= BuildingDataManager.smokeSiaga) {
                tvStatusSmoke.text = "SIAGA"
                tvStatusSmoke.setTextColor(Color.parseColor("#D97706"))
            } else {
                tvStatusSmoke.text = "Aman"
                tvStatusSmoke.setTextColor(Color.parseColor("#059669"))
            }
            containerMq2.addView(rowSmoke)

            // 2. DHT22 Suhu & Kelembapan
            val rowTemp = inflater.inflate(R.layout.item_sensor_detail_row, containerDht, false)
            rowTemp.findViewById<TextView>(R.id.tv_row_sensor_name).text = "Sensor DHT22 (Suhu & Kelembapan) – ${koridor.name}"
            rowTemp.findViewById<TextView>(R.id.tv_row_sensor_loc).text = "Lantai ${koridor.floor}"
            rowTemp.findViewById<TextView>(R.id.tv_row_sensor_val).text = String.format(Locale.US, "%.1f°C | %d%% RH", koridor.tempCelsius, koridor.humidityPercent.toInt())
            val tvStatusTemp = rowTemp.findViewById<TextView>(R.id.tv_row_sensor_status)
            if (koridor.tempCelsius >= BuildingDataManager.tempBahaya) {
                tvStatusTemp.text = "BAHAYA"
                tvStatusTemp.setTextColor(Color.parseColor("#DC2626"))
            } else if (koridor.tempCelsius >= BuildingDataManager.tempSiaga) {
                tvStatusTemp.text = "SIAGA"
                tvStatusTemp.setTextColor(Color.parseColor("#D97706"))
            } else {
                tvStatusTemp.text = "Aman"
                tvStatusTemp.setTextColor(Color.parseColor("#059669"))
            }
            containerDht.addView(rowTemp)

            // 3. Flame Sensor
            if (koridor.id == "L1_A" || koridor.id == "L2_A") {
                val rowFlame = inflater.inflate(R.layout.item_sensor_detail_row, containerFlame, false)
                rowFlame.findViewById<TextView>(R.id.tv_row_sensor_name).text = "Sensor Api (Flame) – Lantai ${koridor.floor}"
                rowFlame.findViewById<TextView>(R.id.tv_row_sensor_loc).text = "Zona Evakuasi Tangga"
                rowFlame.findViewById<TextView>(R.id.tv_row_sensor_val).text = if (koridor.flameDetected) "API TERDETEKSI" else "Tidak Terdeteksi"
                val tvStatusFlame = rowFlame.findViewById<TextView>(R.id.tv_row_sensor_status)
                if (koridor.flameDetected) {
                    tvStatusFlame.text = "BAHAYA"
                    tvStatusFlame.setTextColor(Color.parseColor("#DC2626"))
                } else {
                    tvStatusFlame.text = "Aman"
                    tvStatusFlame.setTextColor(Color.parseColor("#059669"))
                }
                containerFlame.addView(rowFlame)
            }

            // 4. LDR
            if (koridor.id.endsWith("_A") || koridor.id.endsWith("_C")) {
                val rowLdr = inflater.inflate(R.layout.item_sensor_detail_row, containerLdr, false)
                rowLdr.findViewById<TextView>(R.id.tv_row_sensor_name).text = "Sensor Cahaya (LDR) – ${koridor.name}"
                rowLdr.findViewById<TextView>(R.id.tv_row_sensor_loc).text = "Lantai ${koridor.floor}"
                rowLdr.findViewById<TextView>(R.id.tv_row_sensor_val).text = "${koridor.lightLux.toInt()} lux"
                val tvStatusLdr = rowLdr.findViewById<TextView>(R.id.tv_row_sensor_status)
                tvStatusLdr.text = "Normal"
                tvStatusLdr.setTextColor(Color.parseColor("#059669"))
                containerLdr.addView(rowLdr)
            }
        }

        dialog.findViewById<View>(R.id.btn_close_all_sensors).setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun showSopEvacDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.dialog_detail_peringatan_sop)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val evac = BuildingDataManager.getEvacuationRecommendation()
        val alert = BuildingDataManager.getLatestAlert()

        val tvLevel = dialog.findViewById<TextView>(R.id.tv_sop_alert_level)
        val tvTitle = dialog.findViewById<TextView>(R.id.tv_sop_alert_title)
        val tvLoc = dialog.findViewById<TextView>(R.id.tv_sop_alert_location)
        val tvStair = dialog.findViewById<TextView>(R.id.tv_sop_stair_name)
        val tvInstruction = dialog.findViewById<TextView>(R.id.tv_sop_stair_instruction)

        if (alert != null) {
            tvLevel.text = "PERINGATAN BAHAYA AKTIF"
            tvLevel.setTextColor(Color.parseColor("#DC2626"))
            tvTitle.text = alert.first
            tvLoc.text = "Lokasi: ${alert.second}"
        } else {
            tvLevel.text = "STATUS GEDUNG AMAN"
            tvLevel.setTextColor(Color.parseColor("#059669"))
            tvTitle.text = "Tidak Ada Peringatan Bahaya"
            tvLoc.text = "Semua 6 Koridor Gedung Bebas Hambatan"
        }

        tvStair.text = evac.recommendedStair
        tvInstruction.text = evac.instruction

        dialog.findViewById<View>(R.id.btn_close_sop_dialog).setOnClickListener { dialog.dismiss() }

        dialog.findViewById<MaterialButton>(R.id.btn_sop_konfirmasi_petugas).setOnClickListener {
            NotificationHelper.stopAlarmSound()
            dialog.dismiss()
            Toast.makeText(this, "Petugas telah mengonfirmasi dan mencatat penanganan.", Toast.LENGTH_SHORT).show()
        }

        dialog.show()
    }

    private fun showSettingsDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.dialog_settings_firebase)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val rbSimulasi = dialog.findViewById<RadioButton>(R.id.rb_mode_simulasi)
        val rbReal = dialog.findViewById<RadioButton>(R.id.rb_mode_real)
        val etUrl = dialog.findViewById<EditText>(R.id.et_firebase_url)
        val etSmokeSiaga = dialog.findViewById<EditText>(R.id.et_smoke_siaga)
        val etSmokeBahaya = dialog.findViewById<EditText>(R.id.et_smoke_bahaya)
        val etTempSiaga = dialog.findViewById<EditText>(R.id.et_temp_siaga)
        val etTempBahaya = dialog.findViewById<EditText>(R.id.et_temp_bahaya)

        rbReal.isChecked = BuildingDataManager.isRealDeviceMode
        rbSimulasi.isChecked = !BuildingDataManager.isRealDeviceMode
        etUrl.setText(BuildingDataManager.firebaseUrl)
        etSmokeSiaga.setText(BuildingDataManager.smokeSiaga.toString())
        etSmokeBahaya.setText(BuildingDataManager.smokeBahaya.toString())
        etTempSiaga.setText(BuildingDataManager.tempSiaga.toString())
        etTempBahaya.setText(BuildingDataManager.tempBahaya.toString())

        dialog.findViewById<View>(R.id.btn_close_settings_dialog).setOnClickListener { dialog.dismiss() }

        dialog.findViewById<MaterialButton>(R.id.btn_reset_all_safe).setOnClickListener {
            BuildingDataManager.resetAllToSafe()
            dialog.dismiss()
            Toast.makeText(this, "Semua koridor telah di-reset menjadi Normal/Aman.", Toast.LENGTH_SHORT).show()
        }

        dialog.findViewById<MaterialButton>(R.id.btn_save_settings).setOnClickListener {
            val isReal = rbReal.isChecked
            val url = etUrl.text.toString()
            val sSiaga = etSmokeSiaga.text.toString().toFloatOrNull() ?: 250f
            val sBahaya = etSmokeBahaya.text.toString().toFloatOrNull() ?: 400f
            val tSiaga = etTempSiaga.text.toString().toFloatOrNull() ?: 35f
            val tBahaya = etTempBahaya.text.toString().toFloatOrNull() ?: 45f

            BuildingDataManager.saveConfig(this, url, isReal, sSiaga, sBahaya, tSiaga, tBahaya)
            dialog.dismiss()
            Toast.makeText(this, "Pengaturan berhasil disimpan!", Toast.LENGTH_SHORT).show()
        }

        dialog.show()
    }

    private fun showRiwayatDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.dialog_riwayat_aktivitas)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val container = dialog.findViewById<LinearLayout>(R.id.container_riwayat_items)
        val inflater = LayoutInflater.from(this)

        BuildingDataManager.riwayatList.forEach { item ->
            val row = inflater.inflate(R.layout.item_sensor_detail_row, container, false)
            row.findViewById<TextView>(R.id.tv_row_sensor_name).text = item.title
            row.findViewById<TextView>(R.id.tv_row_sensor_loc).text = "${item.location} • Petugas: ${item.officer}"
            row.findViewById<TextView>(R.id.tv_row_sensor_val).text = item.timestamp
            val tvStatus = row.findViewById<TextView>(R.id.tv_row_sensor_status)
            tvStatus.text = item.actionTaken
            tvStatus.setTextColor(Color.parseColor("#38BDF8"))
            container.addView(row)
        }

        dialog.findViewById<View>(R.id.btn_close_riwayat_dialog).setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun showDemoScenariosDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.dialog_demo_scenarios)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        dialog.findViewById<View>(R.id.btn_close_scenario_dialog).setOnClickListener { dialog.dismiss() }

        dialog.findViewById<View>(R.id.card_scenario_1).setOnClickListener {
            lastDangerCount = 0
            lastWarningCount = 0
            lastAlertLocation = null
            BuildingDataManager.runDemoScenario(1)
            dialog.dismiss()
            Toast.makeText(this, "🔥 Skenario 1 Aktif: Asap & Api di Lantai 1 Lorong B", Toast.LENGTH_SHORT).show()
        }

        dialog.findViewById<View>(R.id.card_scenario_2).setOnClickListener {
            lastDangerCount = 0
            lastWarningCount = 0
            lastAlertLocation = null
            BuildingDataManager.runDemoScenario(2)
            dialog.dismiss()
            Toast.makeText(this, "⚠️ Skenario 2 Aktif: Bahaya Lorong A -> Evakuasi ke Tangga B (Kanan)", Toast.LENGTH_SHORT).show()
        }

        dialog.findViewById<View>(R.id.card_scenario_3).setOnClickListener {
            lastDangerCount = 0
            lastWarningCount = 0
            lastAlertLocation = null
            BuildingDataManager.runDemoScenario(3)
            dialog.dismiss()
            Toast.makeText(this, "⚠️ Skenario 3 Aktif: Bahaya Lorong C -> Evakuasi ke Tangga A (Kiri)", Toast.LENGTH_SHORT).show()
        }

        dialog.findViewById<View>(R.id.card_scenario_4).setOnClickListener {
            lastDangerCount = 0
            lastWarningCount = 0
            lastAlertLocation = null
            BuildingDataManager.runDemoScenario(4)
            dialog.dismiss()
            Toast.makeText(this, "🚨 Skenario 4 Aktif: Bahaya di Kedua Tangga -> Peringatan Darurat SOP", Toast.LENGTH_SHORT).show()
        }

        dialog.findViewById<View>(R.id.btn_scenario_reset_safe).setOnClickListener {
            lastDangerCount = 0
            lastWarningCount = 0
            lastAlertLocation = null
            NotificationHelper.stopAlarmSound()
            BuildingDataManager.resetAllToSafe(notify = true)
            dialog.dismiss()
            Toast.makeText(this, "✅ Seluruh Gedung Kembali AMAN (Normal)", Toast.LENGTH_SHORT).show()
        }

        dialog.show()
    }

    override fun onDestroy() {
        super.onDestroy()
        NotificationHelper.shutdown()
        timeHandler.removeCallbacks(timeRunnable)
    }
}
