package com.example.lorongpintar.data

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.example.lorongpintar.model.EvacuationRecommendation
import com.example.lorongpintar.model.HardwareDeviceStatus
import com.example.lorongpintar.model.KoridorState
import com.example.lorongpintar.model.RiwayatData
import com.example.lorongpintar.model.StatusLevel
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

object BuildingDataManager {

    private const val PREFS_NAME = "lorong_pintar_prefs"
    private const val KEY_FIREBASE_URL = "firebase_rtdb_url"
    private const val KEY_IS_REAL_MODE = "is_real_device_mode"
    private const val KEY_THRESHOLD_SMOKE_SIAGA = "threshold_smoke_siaga"
    private const val KEY_THRESHOLD_SMOKE_BAHAYA = "threshold_smoke_bahaya"
    private const val KEY_THRESHOLD_TEMP_SIAGA = "threshold_temp_siaga"
    private const val KEY_THRESHOLD_TEMP_BAHAYA = "threshold_temp_bahaya"

    var isRealDeviceMode = false
    var firebaseUrl = "https://lorongpintar-88f14-default-rtdb.asia-southeast1.firebasedatabase.app/"
    var smokeSiaga = 250f
    var smokeBahaya = 400f
    var tempSiaga = 35f
    var tempBahaya = 45f

    val hardwareStatus = HardwareDeviceStatus()

    // 6 Lorong Gedung 2 Lantai (Sesuai Miniatur Fisik Meja)
    val koridorList = mutableListOf(
        KoridorState("L1_A", 1, "Lorong A", 120f, 30.5f, 67f, false, 480f),
        KoridorState("L1_B", 1, "Lorong B", 120f, 30.5f, 67f, false, 480f),
        KoridorState("L1_C", 1, "Lorong C", 120f, 30.5f, 67f, false, 480f),
        KoridorState("L2_A", 2, "Lorong A", 120f, 30.5f, 67f, false, 480f),
        KoridorState("L2_B", 2, "Lorong B", 120f, 30.5f, 67f, false, 480f),
        KoridorState("L2_C", 2, "Lorong C", 120f, 30.5f, 67f, false, 480f)
    )

    // Riwayat Log Aktivitas
    val riwayatList = mutableListOf(
        RiwayatData("R-1", "Sistem Pengawas Dimulai", "Semua 6 lorong gedung dalam kondisi Aman", getCurrentTime(), "Sistem Siaga", "Ruang Kontrol ESP32"),
        RiwayatData("R-2", "Inisialisasi Sensor Selesai", "6 Sensor Asap, 6 Sensor Suhu, 2 Sensor Api, 4 Sensor Cahaya Aktif", getCurrentTime(), "Normal", "Sistem Otomatis")
    )

    private val listeners = mutableListOf<() -> Unit>()
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var pollingRunnable: Runnable? = null

    fun init(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val defaultUrl = "https://lorongpintar-88f14-default-rtdb.asia-southeast1.firebasedatabase.app/"
        firebaseUrl = prefs.getString(KEY_FIREBASE_URL, defaultUrl)?.ifBlank { defaultUrl } ?: defaultUrl
        isRealDeviceMode = prefs.getBoolean(KEY_IS_REAL_MODE, false)
        smokeSiaga = prefs.getFloat(KEY_THRESHOLD_SMOKE_SIAGA, 250f)
        smokeBahaya = prefs.getFloat(KEY_THRESHOLD_SMOKE_BAHAYA, 400f)
        tempSiaga = prefs.getFloat(KEY_THRESHOLD_TEMP_SIAGA, 35f)
        tempBahaya = prefs.getFloat(KEY_THRESHOLD_TEMP_BAHAYA, 45f)

        recalculateAll()
        startFirebaseSyncIfNeeded()
    }

    fun saveConfig(context: Context, url: String, realMode: Boolean, sSiaga: Float, sBahaya: Float, tSiaga: Float, tBahaya: Float) {
        firebaseUrl = url.trim()
        isRealDeviceMode = realMode
        smokeSiaga = sSiaga
        smokeBahaya = sBahaya
        tempSiaga = tSiaga
        tempBahaya = tBahaya

        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().apply {
            putString(KEY_FIREBASE_URL, firebaseUrl)
            putBoolean(KEY_IS_REAL_MODE, isRealDeviceMode)
            putFloat(KEY_THRESHOLD_SMOKE_SIAGA, smokeSiaga)
            putFloat(KEY_THRESHOLD_SMOKE_BAHAYA, smokeBahaya)
            putFloat(KEY_THRESHOLD_TEMP_SIAGA, tempSiaga)
            putFloat(KEY_THRESHOLD_TEMP_BAHAYA, tempBahaya)
            apply()
        }

        recalculateAll()
        startFirebaseSyncIfNeeded()
        notifyListeners()
    }

    fun registerListener(listener: () -> Unit) {
        if (!listeners.contains(listener)) listeners.add(listener)
    }

    fun unregisterListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    private fun notifyListeners() {
        mainHandler.post {
            listeners.forEach { it.invoke() }
        }
    }

    fun recalculateAll() {
        var hasDanger = false
        var hasSiaga = false

        koridorList.forEach { koridor ->
            val st = koridor.calculateStatus(smokeSiaga, smokeBahaya, tempSiaga, tempBahaya)
            if (st == StatusLevel.BAHAYA) hasDanger = true
            if (st == StatusLevel.SIAGA) hasSiaga = true
        }

        hardwareStatus.buzzerActive = hasDanger
        hardwareStatus.buzzerState = if (hasDanger) "Sirine Berbunyi (BAHAYA)" else if (hasSiaga) "Waspada" else "Siaga (Aman)"

        notifyListeners()
    }

    fun getAmanCount() = koridorList.count { it.status == StatusLevel.AMAN }
    fun getSiagaCount() = koridorList.count { it.status == StatusLevel.SIAGA }
    fun getBahayaCount() = koridorList.count { it.status == StatusLevel.BAHAYA }

    fun getMaxSmoke(): Float = koridorList.maxOfOrNull { it.smokeGasPpm } ?: 120f
    fun getMaxTemp(): Float = koridorList.maxOfOrNull { it.tempCelsius } ?: 30.5f
    fun getAvgHumidity(): Float = (koridorList.map { it.humidityPercent }.average()).toFloat()
    fun isAnyFlameDetected(): Boolean = koridorList.any { it.flameDetected }
    fun getAvgLight(): Float = (koridorList.map { it.lightLux }.average()).toFloat()

    fun getChartData(isTemp: Boolean): List<Float> {
        val base = if (isTemp) getMaxTemp() else getAvgHumidity()
        return listOf(base - 1.8f, base - 0.5f, base + 1.2f, base - 0.3f, base)
    }

    // Rekomendasi Jalur Evakuasi Cerdas (Hanya Tangga Evakuasi A atau B)
    fun getEvacuationRecommendation(): EvacuationRecommendation {
        val dangerCorridors = koridorList.filter { it.status == StatusLevel.BAHAYA }

        if (dangerCorridors.isEmpty()) {
            return EvacuationRecommendation(
                recommendedStair = "Tangga Kiri (A) atau Tangga Kanan (B)",
                instruction = "Semua lorong aman. Kedua tangga evakuasi dapat digunakan bebas.",
                isSafe = true
            )
        }

        val affectedCorridorNames = dangerCorridors.joinToString(", ") { "Lt ${it.floor} ${it.name}" }

        val hasDangerNearStairA = dangerCorridors.any { it.name == "Lorong A" }
        val hasDangerNearStairB = dangerCorridors.any { it.name == "Lorong C" }
        val hasDangerInCenter = dangerCorridors.any { it.name == "Lorong B" }

        return when {
            hasDangerNearStairA && hasDangerNearStairB -> {
                EvacuationRecommendation(
                    recommendedStair = "PERINGATAN DARURAT!",
                    instruction = "Kedua akses tangga evakuasi terancam! Tetap di zona aman dan ikuti SOP serta arahan petugas gedung.",
                    isSafe = false,
                    dangerCorridor = affectedCorridorNames
                )
            }
            hasDangerNearStairA -> {
                EvacuationRecommendation(
                    recommendedStair = "Gunakan Tangga Kanan (Evakuasi B)",
                    instruction = "Bahaya terdeteksi di area Lorong A. Jauhi Tangga Kiri dan segera evakuasi melalui Tangga Kanan (B).",
                    isSafe = true,
                    dangerCorridor = affectedCorridorNames
                )
            }
            hasDangerNearStairB -> {
                EvacuationRecommendation(
                    recommendedStair = "Gunakan Tangga Kiri (Evakuasi A)",
                    instruction = "Bahaya terdeteksi di area Lorong C. Jauhi Tangga Kanan dan segera evakuasi melalui Tangga Kiri (A).",
                    isSafe = true,
                    dangerCorridor = affectedCorridorNames
                )
            }
            hasDangerInCenter -> {
                EvacuationRecommendation(
                    recommendedStair = "Gunakan Tangga Kiri (Evakuasi A)",
                    instruction = "Bahaya terdeteksi di Lorong B. Disarankan menggunakan Tangga Kiri (A) yang aman dan bebas asap.",
                    isSafe = true,
                    dangerCorridor = affectedCorridorNames
                )
            }
            else -> {
                EvacuationRecommendation(
                    recommendedStair = "Gunakan Tangga Kanan (Evakuasi B)",
                    instruction = "Ikuti jalur lampu hijau evakuasi menuju Tangga Kanan (B).",
                    isSafe = true,
                    dangerCorridor = affectedCorridorNames
                )
            }
        }
    }

    fun getLatestAlert(): Pair<String, String>? {
        val dangerous = koridorList.firstOrNull { it.status == StatusLevel.BAHAYA }
            ?: koridorList.firstOrNull { it.status == StatusLevel.SIAGA }

        return if (dangerous != null) {
            val title = when {
                dangerous.flameDetected -> "Sensor Api Terdeteksi"
                dangerous.smokeGasPpm >= smokeBahaya -> "Sensor Asap Kritis (${dangerous.smokeGasPpm.toInt()} ppm)"
                dangerous.tempCelsius >= tempBahaya -> "Sensor Suhu Ekstrem (${dangerous.tempCelsius}°C)"
                dangerous.smokeGasPpm >= smokeSiaga -> "Peningkatan Asap (${dangerous.smokeGasPpm.toInt()} ppm)"
                else -> "Peningkatan Suhu Ruangan"
            }
            val location = "Lantai ${dangerous.floor} – ${dangerous.name}"
            Pair(title, location)
        } else {
            null
        }
    }

    fun setSimulationCorridorState(corridorId: String, smoke: Float, temp: Float, flame: Boolean, lux: Float) {
        val target = koridorList.find { it.id == corridorId } ?: return
        target.smokeGasPpm = smoke
        target.tempCelsius = temp
        target.flameDetected = flame
        target.lightLux = lux

        recalculateAll()

        if (target.status != StatusLevel.AMAN) {
            val alertTitle = if (flame) "Sensor Api Menyala" else if (smoke >= smokeBahaya) "Sensor Asap Kritis" else "Sensor Suhu Tinggi"
            riwayatList.add(0, RiwayatData(
                id = "R-${System.currentTimeMillis()}",
                title = alertTitle,
                location = "Lantai ${target.floor} – ${target.name} (${target.statusNote})",
                timestamp = getCurrentTime(),
                actionTaken = "Sirine aktif & jalur evakuasi dialihkan",
                officer = "Sistem Otomatis Lorong Pintar"
            ))
        }
    }

    // ================= SKENARIO DEMO PRESENTASI CEPAT =================
    fun runDemoScenario(scenarioIndex: Int) {
        when (scenarioIndex) {
            1 -> {
                // Skenario 1: Asap pekat dan api di Lantai 1 Lorong B (Tengah)
                resetAllToSafe(notify = false)
                setSimulationCorridorState("L1_B", smoke = 780f, temp = 52f, flame = true, lux = 620f)
            }
            2 -> {
                // Skenario 2: Bahaya dekat Tangga Kiri (Lorong A Lantai 2) -> Alihkan ke Tangga Kanan (B)
                resetAllToSafe(notify = false)
                setSimulationCorridorState("L2_A", smoke = 820f, temp = 49f, flame = true, lux = 550f)
            }
            3 -> {
                // Skenario 3: Bahaya dekat Tangga Kanan (Lorong C Lantai 1) -> Alihkan ke Tangga Kiri (A)
                resetAllToSafe(notify = false)
                setSimulationCorridorState("L1_C", smoke = 850f, temp = 48f, flame = true, lux = 500f)
            }
            4 -> {
                // Skenario 4: Bahaya ekstrem di kedua tangga (Lorong A dan Lorong C)
                resetAllToSafe(notify = false)
                setSimulationCorridorState("L1_A", smoke = 750f, temp = 46f, flame = true, lux = 500f)
                setSimulationCorridorState("L2_C", smoke = 810f, temp = 50f, flame = true, lux = 520f)
            }
            else -> {
                resetAllToSafe(notify = true)
            }
        }
    }

    fun resetAllToSafe(notify: Boolean = true) {
        koridorList.forEach {
            it.smokeGasPpm = 120f
            it.tempCelsius = 30.5f
            it.humidityPercent = 67f
            it.flameDetected = false
            it.lightLux = 480f
        }
        recalculateAll()
        if (notify) {
            riwayatList.add(0, RiwayatData(
                id = "R-${System.currentTimeMillis()}",
                title = "Gedung Kembali Normal",
                location = "Seluruh 6 Lorong Aman",
                timestamp = getCurrentTime(),
                actionTaken = "Reset status gedung",
                officer = "Petugas Gedung"
            ))
        }
    }

    // Firebase Sync
    private fun startFirebaseSyncIfNeeded() {
        pollingRunnable?.let { mainHandler.removeCallbacks(it) }

        if (!isRealDeviceMode || firebaseUrl.isBlank()) {
            hardwareStatus.esp32Connected = true
            hardwareStatus.esp32LastSeen = "Online (Mode Simulasi)"
            return
        }

        pollingRunnable = object : Runnable {
            override fun run() {
                fetchFromFirebase()
                mainHandler.postDelayed(this, 2500)
            }
        }
        mainHandler.post(pollingRunnable!!)
    }

    private fun fetchFromFirebase() {
        if (firebaseUrl.isBlank()) return

        executor.execute {
            try {
                var cleanUrl = firebaseUrl
                if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
                    cleanUrl = "https://$cleanUrl"
                }
                if (!cleanUrl.endsWith(".json")) {
                    cleanUrl = if (cleanUrl.endsWith("/")) "${cleanUrl}lorong_pintar.json" else "$cleanUrl/lorong_pintar.json"
                }

                val conn = URL(cleanUrl).openConnection() as HttpURLConnection
                conn.requestMethod = "GET"
                conn.connectTimeout = 4000
                conn.readTimeout = 4000

                if (conn.responseCode == 200) {
                    val reader = BufferedReader(InputStreamReader(conn.inputStream))
                    val response = reader.readText()
                    reader.close()

                    if (response.isNotBlank() && response != "null") {
                        parseFirebaseJson(response)
                    }
                } else {
                    hardwareStatus.esp32Connected = false
                    hardwareStatus.esp32LastSeen = "Koneksi Gagal (HTTP ${conn.responseCode})"
                    notifyListeners()
                }
                conn.disconnect()
            } catch (e: Exception) {
                hardwareStatus.esp32Connected = false
                hardwareStatus.esp32LastSeen = "Offline"
                notifyListeners()
            }
        }
    }

    private fun parseFirebaseJson(jsonStr: String) {
        try {
            val root = JSONObject(jsonStr)

            if (root.has("status")) {
                val st = root.getJSONObject("status")
                hardwareStatus.esp32Connected = st.optBoolean("esp32_online", true)
                hardwareStatus.esp32LastSeen = st.optString("last_seen", "Online")
                hardwareStatus.lcdActive = st.optBoolean("lcd_active", true)
            } else {
                hardwareStatus.esp32Connected = true
                hardwareStatus.esp32LastSeen = "Online"
            }

            if (root.has("sensors")) {
                val sensors = root.getJSONObject("sensors")

                koridorList.forEach { koridor ->
                    if (sensors.has(koridor.id)) {
                        val kObj = sensors.getJSONObject(koridor.id)
                        koridor.smokeGasPpm = kObj.optDouble("smoke_ppm", koridor.smokeGasPpm.toDouble()).toFloat()
                        koridor.tempCelsius = kObj.optDouble("temp_c", koridor.tempCelsius.toDouble()).toFloat()
                        koridor.humidityPercent = kObj.optDouble("humidity", koridor.humidityPercent.toDouble()).toFloat()
                        koridor.flameDetected = kObj.optBoolean("flame", koridor.flameDetected)
                        koridor.lightLux = kObj.optDouble("light_lux", koridor.lightLux.toDouble()).toFloat()
                    }
                }
            }

            recalculateAll()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun getCurrentTime(): String {
        return SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) + " WIB"
    }
}
