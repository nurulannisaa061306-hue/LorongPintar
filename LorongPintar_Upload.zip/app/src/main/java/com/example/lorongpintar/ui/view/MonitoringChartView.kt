package com.example.lorongpintar.ui.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View

class MonitoringChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var dataPoints = listOf(28f, 30.5f, 29.2f, 31.8f, 30.5f)
    private var maxValue = 60f
    private var minValue = 0f

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2563EB")
        strokeWidth = 4.5f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private val dotGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2563EB")
        style = Paint.Style.FILL
    }

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E2E8F0")
        strokeWidth = 1f
        style = Paint.Style.STROKE
    }

    fun setData(points: List<Float>, max: Float = 60f, min: Float = 0f) {
        this.dataPoints = points
        this.maxValue = max
        this.minValue = min
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (dataPoints.isEmpty()) return

        val paddingLeft = 16f
        val paddingRight = 16f
        val paddingTop = 16f
        val paddingBottom = 16f

        val w = width.toFloat() - paddingLeft - paddingRight
        val h = height.toFloat() - paddingTop - paddingBottom

        if (w <= 0 || h <= 0) return

        // Draw horizontal grid lines
        val gridCount = 3
        for (i in 0..gridCount) {
            val y = paddingTop + (h / gridCount) * i
            canvas.drawLine(paddingLeft, y, width - paddingRight, y, gridPaint)
        }

        val stepX = w / (dataPoints.size - 1).coerceAtLeast(1)

        val path = Path()
        val fillPath = Path()

        val pointsX = FloatArray(dataPoints.size)
        val pointsY = FloatArray(dataPoints.size)

        for (i in dataPoints.indices) {
            val px = paddingLeft + i * stepX
            val normalized = (dataPoints[i] - minValue) / (maxValue - minValue).coerceAtLeast(1f)
            val py = paddingTop + h * (1f - normalized.coerceIn(0f, 1f))
            pointsX[i] = px
            pointsY[i] = py

            if (i == 0) {
                path.moveTo(px, py)
                fillPath.moveTo(px, py)
            } else {
                val prevX = pointsX[i - 1]
                val prevY = pointsY[i - 1]
                val midX = (prevX + px) / 2f
                path.cubicTo(midX, prevY, midX, py, px, py)
                fillPath.cubicTo(midX, prevY, midX, py, px, py)
            }
        }

        // Complete fill area down to bottom
        fillPath.lineTo(pointsX.last(), paddingTop + h)
        fillPath.lineTo(pointsX.first(), paddingTop + h)
        fillPath.close()

        // Clean modern blue gradient wash for light mode
        val gradient = LinearGradient(
            0f, paddingTop,
            0f, paddingTop + h,
            Color.parseColor("#262563EB"),
            Color.parseColor("#00F8FAFC"),
            Shader.TileMode.CLAMP
        )
        fillPaint.shader = gradient
        canvas.drawPath(fillPath, fillPaint)

        // Draw main curve
        canvas.drawPath(path, linePaint)

        // Draw refined dots
        for (i in dataPoints.indices) {
            canvas.drawCircle(pointsX[i], pointsY[i], 6.5f, dotGlowPaint)
            canvas.drawCircle(pointsX[i], pointsY[i], 3.5f, dotPaint)
        }
    }
}
