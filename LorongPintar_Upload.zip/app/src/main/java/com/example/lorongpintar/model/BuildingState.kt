package com.example.lorongpintar.model

enum class StatusLevel {
    AMAN, SIAGA, BAHAYA
}

data class KoridorState(
    val id: String, // "L1_A", "L1_B", "L1_C", "L2_A", "L2_B", "L2_C"
    val floor: Int, // 1 or 2
    val name: String, // "Lorong A", "Lorong B", "Lorong C"
    var smokeGasPpm: Float = 120f,
    var tempCelsius: Float = 30.5f,
    var humidityPercent: Float = 67f,
    var flameDetected: Boolean = false,
    var lightLux: Float = 480f,
    var status: StatusLevel = StatusLevel.AMAN,
    var statusNote: String = "Normal"
) {
    fun calculateStatus(smokeThresholdSiaga: Float = 250f, smokeThresholdBahaya: Float = 400f,
                        tempThresholdSiaga: Float = 35f, tempThresholdBahaya: Float = 45f): StatusLevel {
        return when {
            flameDetected || smokeGasPpm >= smokeThresholdBahaya || tempCelsius >= tempThresholdBahaya -> {
                status = StatusLevel.BAHAYA
                statusNote = when {
                    flameDetected -> "Terdeteksi Nyala Api"
                    smokeGasPpm >= smokeThresholdBahaya -> "Kadar Asap/Gas Kritis (${smokeGasPpm.toInt()} ppm)"
                    else -> "Suhu Sangat Tinggi (${tempCelsius}°C)"
                }
                StatusLevel.BAHAYA
            }
            smokeGasPpm >= smokeThresholdSiaga || tempCelsius >= tempThresholdSiaga -> {
                status = StatusLevel.SIAGA
                statusNote = when {
                    smokeGasPpm >= smokeThresholdSiaga -> "Kadar Asap/Gas Meningkat (${smokeGasPpm.toInt()} ppm)"
                    else -> "Suhu Meningkat (${tempCelsius}°C)"
                }
                StatusLevel.SIAGA
            }
            else -> {
                status = StatusLevel.AMAN
                statusNote = "Normal"
                StatusLevel.AMAN
            }
        }
    }
}

data class EvacuationRecommendation(
    val recommendedStair: String, // "Tangga Evakuasi A", "Tangga Evakuasi B", or "Prosedur Evakuasi Khusus"
    val instruction: String,
    val isSafe: Boolean,
    val dangerCorridor: String? = null
)

data class HardwareDeviceStatus(
    var esp32Connected: Boolean = true,
    var esp32LastSeen: String = "Online",
    var lcdActive: Boolean = true,
    var buzzerActive: Boolean = false,
    var buzzerState: String = "Siaga"
)

