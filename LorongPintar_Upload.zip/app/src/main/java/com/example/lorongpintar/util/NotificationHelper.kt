package com.example.lorongpintar.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import com.example.lorongpintar.MainActivity
import com.example.lorongpintar.R

object NotificationHelper {

    // Menggunakan Channel ID baru agar Android OS menerapkan file suara kustom peringatan, bukan nada bawaan HP
    private const val CHANNEL_ID_DANGER = "lorong_pintar_alert_warning_sound_v12"
    private const val CHANNEL_NAME_DANGER = "Peringatan Bahaya Kebakaran"
    private const val CHANNEL_DESC_DANGER = "Suara nada peringatan bahaya kebakaran gedung"

    private const val CHANNEL_ID_WARNING = "lorong_pintar_alert_siaga_sound_v12"
    private const val CHANNEL_NAME_WARNING = "Peringatan Siaga Kebakaran"
    private const val CHANNEL_DESC_WARNING = "Suara nada peringatan siaga gedung"

    private const val NOTIFICATION_ID_DANGER = 1001
    private const val NOTIFICATION_ID_WARNING = 1002

    private var mediaPlayer: MediaPlayer? = null
    private var channelsCreated = false

    fun createNotificationChannels(context: Context) {
        if (channelsCreated) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_ALARM)
                .build()

            // 1. Channel Bahaya Kebakaran (Suara Peringatan Bahaya Kustom)
            val dangerSoundUri = Uri.parse("${ContentResolver.SCHEME_ANDROID_RESOURCE}://${context.packageName}/${R.raw.peringatan_bahaya}")
            val dangerChannel = NotificationChannel(
                CHANNEL_ID_DANGER,
                CHANNEL_NAME_DANGER,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = CHANNEL_DESC_DANGER
                enableLights(true)
                lightColor = Color.RED
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 400, 200, 400)
                setSound(dangerSoundUri, audioAttributes)
            }
            notificationManager.createNotificationChannel(dangerChannel)

            // 2. Channel Siaga (Suara Peringatan Siaga Kustom)
            val warningSoundUri = Uri.parse("${ContentResolver.SCHEME_ANDROID_RESOURCE}://${context.packageName}/${R.raw.peringatan_siaga}")
            val warningChannel = NotificationChannel(
                CHANNEL_ID_WARNING,
                CHANNEL_NAME_WARNING,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = CHANNEL_DESC_WARNING
                enableLights(true)
                lightColor = Color.parseColor("#D97706")
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 150, 250)
                setSound(warningSoundUri, audioAttributes)
            }
            notificationManager.createNotificationChannel(warningChannel)

            channelsCreated = true
        }
    }

    fun createNotificationChannel(context: Context) {
        createNotificationChannels(context)
    }

    fun showEmergencyAlert(
        context: Context,
        alertTitle: String,
        alertLocation: String,
        recommendedStair: String
    ) {
        createNotificationChannels(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val dangerSoundUri = Uri.parse("${ContentResolver.SCHEME_ANDROID_RESOURCE}://${context.packageName}/${R.raw.peringatan_bahaya}")

        val notification = NotificationCompat.Builder(context, CHANNEL_ID_DANGER)
            .setSmallIcon(R.drawable.ic_shield_flame)
            .setContentTitle("🚨 $alertTitle")
            .setContentText("$alertLocation • Jalur: $recommendedStair")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("Bahaya kebakaran terdeteksi di $alertLocation!\n\nJalur Evakuasi Disarankan:\n$recommendedStair\n\nSegera lakukan evakuasi dan ikuti SOP keselamatan gedung.")
            )
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setSound(dangerSoundUri)
            .setVibrate(longArrayOf(0, 400, 200, 400))
            .setContentIntent(pendingIntent)
            .build()

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID_DANGER, notification)

        // Putar suara peringatan bahaya kustom
        playAlertAudio(context, isEmergency = true)

        // Getar HP
        triggerPhoneVibration(context, isEmergency = true)
    }

    fun showWarningAlert(
        context: Context,
        alertTitle: String,
        alertLocation: String
    ) {
        createNotificationChannels(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            1,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val warningSoundUri = Uri.parse("${ContentResolver.SCHEME_ANDROID_RESOURCE}://${context.packageName}/${R.raw.peringatan_siaga}")

        val notification = NotificationCompat.Builder(context, CHANNEL_ID_WARNING)
            .setSmallIcon(R.drawable.ic_warning)
            .setContentTitle("⚠️ PERINGATAN SIAGA: $alertTitle")
            .setContentText("$alertLocation • Periksa lokasi sebelum eskalasi")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("Indikasi awal terdeteksi di $alertLocation!\n\nStatus: SIAGA (Waspada).\nPetugas diminta melakukan pengecekan visual sensor.")
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setSound(warningSoundUri)
            .setVibrate(longArrayOf(0, 250, 150, 250))
            .setContentIntent(pendingIntent)
            .build()

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID_WARNING, notification)

        // Putar suara peringatan siaga kustom
        playAlertAudio(context, isEmergency = false)

        // Getar HP
        triggerPhoneVibration(context, isEmergency = false)
    }

    private fun playAlertAudio(context: Context, isEmergency: Boolean) {
        try {
            stopAlarmSound()

            val rawRes = if (isEmergency) R.raw.peringatan_bahaya else R.raw.peringatan_siaga
            mediaPlayer = MediaPlayer.create(context, rawRes)

            mediaPlayer?.apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .build()
                )
                setOnCompletionListener { mp ->
                    try {
                        mp.release()
                        if (mediaPlayer == mp) mediaPlayer = null
                    } catch (_: Exception) {}
                }
                start()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun stopAlarmSound() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.stop()
                }
                it.release()
            }
            mediaPlayer = null
        } catch (_: Exception) {}
    }

    fun shutdown() {
        stopAlarmSound()
    }

    private fun triggerPhoneVibration(context: Context, isEmergency: Boolean = true) {
        try {
            val pattern = if (isEmergency) {
                longArrayOf(0, 400, 200, 400)
            } else {
                longArrayOf(0, 250, 150, 250)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createWaveform(pattern, -1)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createWaveform(pattern, -1))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(pattern, -1)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
