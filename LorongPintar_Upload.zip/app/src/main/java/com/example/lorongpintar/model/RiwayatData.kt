package com.example.lorongpintar.model

data class RiwayatData(
    val id: String,
    val title: String,
    val location: String,
    val timestamp: String,
    val actionTaken: String,
    val officer: String
)
